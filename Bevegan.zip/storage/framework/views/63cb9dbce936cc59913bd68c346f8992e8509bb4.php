<?php $__env->startSection('content'); ?>
<h2 class="text-center">Detalle de la Marca</h2>
<div class="row mt-5">
    <div class="col-lg-4 offset-lg-4">
            <ul class="list-group list-group-flush">
                <li class="list-group-item ">Marca: <?php echo e($marcas->nombre); ?></li>
            </ul>
    </div>
       <a href="/marcaListado" class="btn btn-danger">Volver</a>


    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/marca/marcaDetalle.blade.php ENDPATH**/ ?>