<?php $__env->startSection('content'); ?>
<h2 class="text-center">Agregar Producto</h2>
<div class="container-fluid">
        <div class="row mt-5">
    <div class="col-lg-8 offset-lg-2">
        <?php if(count($errors->all())>0): ?>
            <ul class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <form action="/productoGuardar" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nombre">Nombre del Producto</label>
                <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>">

                <dl class="param param-feature">
                    <dt>Categoría</dt>
                    <dd>
                        <select name="categoria_id" id="categoria_id">
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </dd>
                </dl> 
                
                <dl class="param param-feature">
                    <dt>Marca</dt>
                    <dd>
                        <select name="marca_id" id="marca_id">
                            <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </dd>
                </dl> 

                <label for="precio">Precio </label>
                <input type="text" class="form-control" name="precio" id="precio" value="<?php echo e(old('precio')); ?>">

                <label for="modelo">Modelo </label>
                <input type="text" class="form-control" name="modelo" id="modelo" value="<?php echo e(old('modelo')); ?>">

                <label for="imagen">Imagen</label>
                <input type="file" value="imageLoc" class='form-control-file' name="imagen" id="imagen">



            </div>
            <button type="submit" class="btn btn-primary">Registrar producto</button>
        </form>
        
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/producto/productoAgregar.blade.php ENDPATH**/ ?>