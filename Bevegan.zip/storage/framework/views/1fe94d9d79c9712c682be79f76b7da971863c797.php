<?php $__env->startSection('content'); ?>
<h2 class="text-center">Editar Producto <?php echo e($productoEditar->nombre); ?></h2>
<div class="container-fluid">
<div class="row mt-5">
     <div class="col-lg-8 offset-lg-2">
         
        <?php if(count($errors->all())>0): ?>
            <ul class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
        <form action="/productoEditadaGuardar/<?php echo e($productoEditar->id); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>    
            <div class="form-group">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item ">
                    <img src="/storage/<?php echo e($productoEditar->imagen); ?>" alt="">    
                    </li>
                </ul>                 

                <label for="nombre">Nombre de la producto </label>
                 <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(old('nombre', $productoEditar->nombre)); ?>">
                 
                 <label for="categoria_id">Categoria </label>
                 <select name="categoria_id" class="form-control" id="categoria_id">
                    <option value="<?php echo e($productoEditar->categoria['id']); ?>" selected><?php echo e($productoEditar->categoria['nombre']); ?></option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($categoria->nombre != $productoEditar->categoria['nombre']): ?>
                            <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>                
                
                <label for="marca_id">Marca </label>
                 <select name="marca_id" class="form-control" id="marca_id">
                    <option value="<?php echo e($productoEditar->marca['id']); ?>" selected><?php echo e($productoEditar->marca['nombre']); ?></option>
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($marca->nombre != $productoEditar->marca['nombre']): ?>
                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nombre); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
 
                 <label for="precio">Precio </label>
                 <input type="text" class="form-control" name="precio" id="precio" value="<?php echo e(old('precio', $productoEditar->precio)); ?>">

                 <label for="modelo">Modeo </label>
                 <input type="text" class="form-control" name="modelo" id="modelo" value="<?php echo e(old('modelo', $productoEditar->modelo)); ?>">


                <label for="imagen">Cargar / Modificar Imagen</label>
                <input type="file" value="imageLoc" class='form-control-file' name="imagen" id="imagen">



            </div>
             
             
             <button type="submit" class="btn btn-primary">Actualizar producto</button>
        </form>
        <a href="/productoListado" class="btn btn-danger">Volver</a>    
     </div>
     
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/producto/productoEditar.blade.php ENDPATH**/ ?>