<?php $__env->startSection('content'); ?>
<h2 class="text-center">Agregar Marca</h2>
<div class="container-fluid">
        <div class="row mt-5">
    <div class="col-lg-8 offset-lg-2">
        <?php if(count($errors->all())>0): ?>
            <ul class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <form action="/marcaGuardar" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nombre">Nombre de la Marca</label>
                <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Registrar Marca</button>
        </form>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/marca/marcaAgregar.blade.php ENDPATH**/ ?>