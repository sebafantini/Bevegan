<?php $__env->startSection('content'); ?>
<h2 class="text-center">Detalle del Producto</h2>
<div class="row mt-5">
    <div class="col-lg-4 offset-lg-4">
            <ul class="list-group list-group-flush">
                <li class="list-group-item ">
                <img src="/storage/<?php echo e($productos->imagen); ?>" alt="">    
                </li>
            </ul>            

            <ul class="list-group list-group-flush">
                <li class="list-group-item ">Producto: <?php echo e($productos->nombre); ?></li>
            </ul>            
            <ul class="list-group list-group-flush">
                <li class="list-group-item ">Categoria: <?php echo e($productos->categoria['nombre']); ?></li>
            </ul>
            <ul class="list-group list-group-flush">
                <li class="list-group-item ">Marca: <?php echo e($productos->marca['nombre']); ?></li>
            </ul>
            <ul class="list-group list-group-flush">
                <li class="list-group-item ">Precio: $ <?php echo e($productos->precio); ?></li>
            </ul>            
            <ul class="list-group list-group-flush">                
                <a href="/productoListado" class="btn btn-danger">Volver</a>        
            </ul>            


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/producto/productoDetalle.blade.php ENDPATH**/ ?>