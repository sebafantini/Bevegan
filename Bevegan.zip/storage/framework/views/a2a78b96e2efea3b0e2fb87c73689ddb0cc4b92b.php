<?php $__env->startSection('content'); ?>

<div class="container-fluid row">
        <div class="container">
                <div class="row fp-contenedor-login">




<div class="  p-3 col-12 col-sm-12 col-md-8 col-lg-6 align-center">

    
    <h2 class="fp-titulo-bienvenida">Mi Cuenta!</h2>
    <div  class=" contenedor-informacion">
        <div class="linea">
                <h6 class="titulo-contenedor">Informacion personal</h6><a class="editar" href="editar-informacion-cuenta.php">Editar</a>
        </div>
        <br>
        <div class="contenido-contenedor">
        <p class="informacion-mi-cuenta"></p> <img class="icono-cuenta" src="img/icon-usuario.png" alt=""> <?php echo e(Auth::user()->name); ?></p>
        <p class="informacion-mi-cuenta"> <img class="icono-cuenta" src="img/icon-email.png" alt=""> Email: <?php echo e(Auth::user()->email); ?></p>                                            
        <p class="informacion-mi-cuenta"> <img class="icono-cuenta" src="img/icon-telefono.png" alt=""> Telefono: <?php echo e(Auth::user()->telefono); ?></p>
        <p class="informacion-mi-cuenta"> <img class="icono-cuenta" src="img/icon-ciudad.png" alt=""> Direccion: <?php echo e(Auth::user()->calle); ?> <?php echo e(Auth::user()->numero); ?></p>
        <p class="informacion-mi-cuenta"> <img class="icono-cuenta" src="img/icon-ciudad.png" alt=""> Piso: <?php echo e(Auth::user()->piso); ?></p>
        <p class="informacion-mi-cuenta"> <img class="icono-cuenta" src="img/icon-ciudad.png" alt=""> Letra: <?php echo e(Auth::user()->letra); ?></p>
        <p class="informacion-mi-cuenta"> <img class="icono-cuenta" src="img/icon-ciudad.png" alt=""> Provincia: <?php echo e(Auth::user()->provincia); ?></p>
        <p class="informacion-mi-cuenta"> <img class="icono-cuenta" src="img/icon-ciudad.png" alt=""> Localidad: <?php echo e(Auth::user()->municipio); ?></p>
        
        </div>
</div>

                
        
       
                      
 </div>
       
    
                    
            
           
                          
     
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/perfil.blade.php ENDPATH**/ ?>