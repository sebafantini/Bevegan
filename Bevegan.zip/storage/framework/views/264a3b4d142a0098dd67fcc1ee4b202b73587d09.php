<?php $__env->startSection('content'); ?>
<h2 class="text-center">Listado de todas tus Marcas</h2>
<div>
    <form class="form-inline" action="/buscarMarca" method="GET" >
        <?php echo csrf_field(); ?>
        <input class="btn btn-primary " type="submit" value="Buscar"><input class="form-control mx-sm-3" type="text" name="busqueda">
        <a class="btn btn-success " href="/marcaAgregar">Agregar Marca</a>
      </form>
</div>

<div class="spacer">
<table class="table">
    <thead>
    <tr>
        <th>Id</th>
        <th>Nombre</th>
        <th>Ver</th>
        <th>Editar</th>
        <th>Eliminar</th>
    </tr>
    </thead>
    <tbody>
       
        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e($value->nombre); ?></td>
            <td><a href="/marcaDetalle/<?php echo e($value->id); ?>"><ion-icon name="eye"></ion-icon></a></td>
            <td><a href="/marcaEditar/<?php echo e($value->id); ?>"><ion-icon name="create"></ion-icon></a></td>
            <td><a href="/marcaEliminar/<?php echo e($value->id); ?>"><ion-icon name="trash"></ion-icon></td></a>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>

    </tr>
    </tbody>
</table>
<div>
    <?php echo e($marcas->links()); ?>

</div>

</div>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/marca/marcaListado.blade.php ENDPATH**/ ?>