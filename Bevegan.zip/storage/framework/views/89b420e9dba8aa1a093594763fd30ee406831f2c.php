<?php $__env->startSection('content'); ?>
<div class="container-fluid row">
    <div class="container">
    
<h2 class="fp-letra-principal text-center">Compras</h2>
<div class=" fp-productos-compras row">

<div class="card mb-3 mr-md-3" style="max-width: 540px;">
    <div class="row no-gutters">
      <div class="col-md-4">
        <img src="img/helado.jpg" class="card-img" alt="...">
      </div>
      <div class="col-md-8">
        <div class="card-body">
            <a class="text-decoration-none" href=""><h5 class="card-title text-secondary">Nombre del Producto</h5></a>
            <p class="card-text">Descpricion breve del producto.</p>
            <p class="card-text">Fecha de Compra</p>
            <p class="card-text"><small class="text-muted"> $400,- Pagado</small></p>
        </div>
      </div>
    </div>
  </div>
  <br>
  <div class="card mb-3 mr-md-3" style="max-width: 540px;">
      <div class="row no-gutters">
        <div class="col-md-4">
          <img src="img/helado.jpg" class="card-img" alt="...">
        </div>
        <div class="col-md-8">
          <div class="card-body">
            <a class="text-decoration-none" href=""><h5 class="card-title text-secondary">Nombre del Producto</h5></a>
            <p class="card-text">Descpricion breve del producto.</p>
            <p class="card-text">Fecha de Compra</p>
            <p class="card-text"><small class="text-muted">$400,-Pagado</small></p>
          </div>
        </div>
      </div>
    </div>
    <div class="card mb-3 mr-md-3" style="max-width: 540px;">
        <div class="row no-gutters">
          <div class="col-md-4">
            <img src="img/helado.jpg" class="card-img" alt="...">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <a class="text-decoration-none" href=""><h5 class="card-title text-secondary">Nombre del Producto</h5></a>
              <p class="card-text">Descpricion breve del producto.</p>
              <p class="card-text">Fecha de Compra</p>
              <p class="card-text"><small class="text-muted">$400,-Pagado</small></p>
            </div>
          </div>
        </div>
      </div>
      <div class="card mb-3 mr-md-3" style="max-width: 540px;">
          <div class="row no-gutters">
            <div class="col-md-4">
              <img src="img/helado.jpg" class="card-img" alt="...">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <a class="text-decoration-none" href=""><h5 class="card-title text-secondary">Nombre del Producto</h5></a>
                <p class="card-text">Descpricion breve del producto.</p>
                <p class="card-text">Fecha de Compra</p>
                <p class="card-text"><small class="text-muted">$400,-Pagado</small></p>
              </div>
            </div>
          </div>
        </div>
       

            
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/compras.blade.php ENDPATH**/ ?>