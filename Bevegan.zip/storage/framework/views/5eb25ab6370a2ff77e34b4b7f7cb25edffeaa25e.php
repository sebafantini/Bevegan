<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row fp-contenedor-presentacion">
            
            
            <div class="fp-contenido-presentacion p-3 col-6 col-sm-12 col-md-12 col-lg-6 align-center">
              
              <h4 class="text-center fp-letra-principal ">BeVegam</h4>
              <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam sint recusandae, commodi corrupti aspernatur deserunt 
                    placeat pariatur repellendus quia! Quidem eius repellat assumenda voluptatum impedit iure neque quasi, eaque natus.</p>


          </div>

          <div class="d-none d-md-block  p-3 col-6 col-sm-12 col-md-12 col-lg-6 align-center">
              <img class="imagen-presentacion" src="img/conejo.jpg" alt="">
              
              
            </div>

    
    
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adrian\Desktop\laravel\SprintLaravel\Bevegan\resources\views/home.blade.php ENDPATH**/ ?>