<?php

namespace App\Http\Controllers;

class AdministrarCategoriasController extends Controller
{

    
}